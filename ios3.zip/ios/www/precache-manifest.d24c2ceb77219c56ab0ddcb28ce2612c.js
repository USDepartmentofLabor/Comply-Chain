self.__precacheManifest = [
  {
    "revision": "3bf8edb007096a32924140af10c6d42f",
    "url": "./static/media/cocoa_supply_chains_es.3bf8edb0.png"
  },
  {
    "revision": "44afb4638e7b2c881ac8",
    "url": "./static/css/main.12732129.chunk.css"
  },
  {
    "revision": "9eb600ee07a27cdad64f",
    "url": "./static/js/runtime~main.9eb600ee.js"
  },
  {
    "revision": "5182da425f811908bed9f5b8c72fa44f",
    "url": "./static/media/SourceSansPro-Regular.5182da42.ttf"
  },
  {
    "revision": "6e77853c0fc97d5af5dc",
    "url": "./static/js/2.6e77853c.chunk.js"
  },
  {
    "revision": "06b89f1b183c591ee831478a61132bba",
    "url": "./static/media/us_flag.06b89f1b.png"
  },
  {
    "revision": "32e164fe55a843982c549a397c7a103e",
    "url": "./static/media/verite.32e164fe.png"
  },
  {
    "revision": "67d4a153bd721c7d237a69f1326410a2",
    "url": "./static/media/betterwork.67d4a153.jpg"
  },
  {
    "revision": "4101b3a29bedfff651ec3eee3c9dd0d0",
    "url": "./static/media/child_brick.4101b3a2.jpg"
  },
  {
    "revision": "d5f1e7c8d6e0483c2b2e32fffe581705",
    "url": "./static/media/leap.d5f1e7c8.png"
  },
  {
    "revision": "8996f665defb9e2860ba47ce0b81c669",
    "url": "./static/media/goodweave.8996f665.jpg"
  },
  {
    "revision": "ccb58eeb7684abdf0073d5cb3051404a",
    "url": "./static/media/hrm.ccb58eeb.jpg"
  },
  {
    "revision": "8c5e3ee8d354e32d9037b4c9cd778502",
    "url": "./static/media/panos.8c5e3ee8.jpg"
  },
  {
    "revision": "f9d92ef2221bba7850dff530a196a24e",
    "url": "./static/media/ilo.f9d92ef2.jpg"
  },
  {
    "revision": "a704315a87dbc860b729b6bcf9c06010",
    "url": "./static/media/usdol.a704315a.jpg"
  },
  {
    "revision": "09189cf804cc789329458120f1e06968",
    "url": "./static/media/man_bamboo.09189cf8.jpg"
  },
  {
    "revision": "fbce53529459b602bbe48e9bfad46ae7",
    "url": "./static/media/graph.fbce5352.jpg"
  },
  {
    "revision": "b593e4a1efbd73eecb68e8de91f4acc6",
    "url": "./static/media/graph_es.b593e4a1.jpg"
  },
  {
    "revision": "c89a57e8a27227906cedae7ddded460f",
    "url": "./static/media/graph_fr.c89a57e8.jpg"
  },
  {
    "revision": "410fac55c03e104ea5a5ee4511e54a72",
    "url": "./static/media/UNO_DC.410fac55.png"
  },
  {
    "revision": "18f8e1be99f4f5255852ac8f22d7b7af",
    "url": "./static/media/UNO_DC_es.18f8e1be.png"
  },
  {
    "revision": "f89f3cc1838b6fa2f921ad9d3c7ef867",
    "url": "./static/media/UNO_DC_fr.f89f3cc1.png"
  },
  {
    "revision": "fbb85ec52f92e596d5e6950e157d590f",
    "url": "./static/media/cocoa_supply_chains.fbb85ec5.png"
  },
  {
    "revision": "6691184efd78463c2662be9b24576e27",
    "url": "./static/media/generic_import.6691184e.png"
  },
  {
    "revision": "44afb4638e7b2c881ac8",
    "url": "./static/js/main.44afb463.chunk.js"
  },
  {
    "revision": "640ca216bf868009d4b9164cdcd9c220",
    "url": "./static/media/generic_import_es.640ca216.png"
  },
  {
    "revision": "ffc7c00ff78ed42f1d8039b23a4c0d7e",
    "url": "./static/media/cocoa_supply_chains_fr.ffc7c00f.png"
  },
  {
    "revision": "74b91e05bd79f5c6ae1378c655eb8c19",
    "url": "./static/media/generic_import_fr.74b91e05.png"
  },
  {
    "revision": "8775c4deed3c057959a8898af5431ccf",
    "url": "./static/media/home_basics.8775c4de.jpg"
  },
  {
    "revision": "ca626bcdeacb2dfc98655ec075d59030",
    "url": "./static/media/home_step_1.ca626bcd.jpg"
  },
  {
    "revision": "98f340f663cb091207d664e483ba5eb3",
    "url": "./static/media/home_step_2.98f340f6.jpg"
  },
  {
    "revision": "8e85513d545cf701246cb76264cbd0cb",
    "url": "./static/media/home_step_3.8e85513d.jpg"
  },
  {
    "revision": "5ad100ee018633e1c80f26f6f05fe405",
    "url": "./static/media/home_step_4.5ad100ee.jpg"
  },
  {
    "revision": "64f08af2dd2d1be3a1ad70a1801bcef0",
    "url": "./static/media/home_step_5.64f08af2.jpg"
  },
  {
    "revision": "6ae7fdf7ec56f8fe639ffbc0d52a5651",
    "url": "./static/media/home_step_6.6ae7fdf7.jpg"
  },
  {
    "revision": "5dcd389366cab1409f7ce8d1b992f712",
    "url": "./static/media/home_step_7.5dcd3893.jpg"
  },
  {
    "revision": "71ef327dc83d5e2f7379eb48a27c9d14",
    "url": "./static/media/home_step_8.71ef327d.jpg"
  },
  {
    "revision": "77b000915a3179c4e74be511933b0d92",
    "url": "./static/media/home_why_develop.77b00091.jpg"
  },
  {
    "revision": "3649694aaf4965130ec51f6dbfd6a928",
    "url": "./static/media/dol-white.3649694a.png"
  },
  {
    "revision": "d18509b17ce5da6b5f72f326824e3454",
    "url": "./static/media/splash.d18509b1.jpg"
  },
  {
    "revision": "3a686627ddd3dfd3ce816d65ac2845fc",
    "url": "./static/media/dol.3a686627.png"
  },
  {
    "revision": "764c2cc5318c856dfccb29cd8529b51d",
    "url": "./static/media/SourceSansPro-Italic.764c2cc5.ttf"
  },
  {
    "revision": "d9f26381ab442285d6c40582942f9a55",
    "url": "./static/media/Merriweather-Bold.d9f26381.ttf"
  },
  {
    "revision": "050f130509046b5350bb0da6232451b7",
    "url": "./static/media/Merriweather-Italic.050f1305.ttf"
  },
  {
    "revision": "fa69aefa0e27b92850101f262338396f",
    "url": "./static/media/Merriweather-Regular.fa69aefa.ttf"
  },
  {
    "revision": "0d9b62a03206f739cd34b2936a5929f1",
    "url": "./static/media/SourceSansPro-Bold.0d9b62a0.ttf"
  },
  {
    "revision": "6e77853c0fc97d5af5dc",
    "url": "./static/css/2.2cb64e14.chunk.css"
  },
  {
    "revision": "904846858262be0870c470ae8f4382a9",
    "url": "./index.html"
  }
];